const fs = require('fs');
const path = require('path');
const name = "data.json";
if (fs.existsSync(name)) {
  // 删除
  fs.unlinkSync(name);
}
fs.writeFileSync(name, "日1子");


