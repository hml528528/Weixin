const fs = require('fs');
const path = require('path');


const dirPath = "../paths/t/dnpicture";
const filesName = fs.readdirSync(dirPath);
const set = new Set();
filesName.forEach(fileName => {
  const fullName = path.join(dirPath, fileName);
  const content = fs.readFileSync(fullName, "utf8");
  JSON.parse(content).forEach(v => {
    const avatar = v.user && v.user.avatar;
    const src = v.thumb || v.img || v.cover;
    const video = v.video ;
    if (avatar) {
      set.add(avatar);
    }
    if (src) {
      set.add(src);
    }
    if (video) {
      set.add(video);
    }
  })
})
console.log(set.size);
fs.writeFileSync("../paths/all.json", JSON.stringify([...set]));