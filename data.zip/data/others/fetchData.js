/* 
cover 小编精选
month 月份
 */
const axios = require("axios");
const MongoClient = require('mongodb').MongoClient;

// Connection URL
const url = 'mongodb://root:root@localhost:27017/?serverSelectionTimeoutMS=5000&connectTimeoutMS=10000&authSource=admin&authMechanism=SCRAM-SHA-256&3t.uriVersion=3&3t.connection.name=t';

// Database Name
const dbName = 'dnpicture';
// Use connect method to connect to the server
MongoClient.connect(url, async function (err, client) {
  console.log("成功连接");
  const db = client.db(dbName);
  // await db.dropDatabase(dbName)
  // await Promise.all([get1(db), get2(db), get3(db)]);
  // await Promise.all([get4(db)]);
  await Promise.all([get5(db)]);
  console.log("插入成功");
  client.close();
});

// 首页 小编精选 和 月份 和 热门(150条)
async function get1(db) {
  const res = await axios.get("http://service.picasso.adesk.com/v4/homepage/vertical?limit=30&adult=false&did=&first=1&order=hot");
  // // 小编精选
  const cover = res.data.res.homepage[1].items;
  db.collection("cover").insertMany(cover);
  // // 月份
  const month = res.data.res.homepage[2].items;
  db.collection("month").insertMany(month);

  // 加载150条
  let times = 0;
  let verticals = [];
  while (times < 5) {
    const skip = times * 30;
    const res2 = await axios.get(`http://service.picasso.adesk.com/v4/homepage/vertical?limit=30&skip=${skip}&adult=false&did=&first=0&order=hot`)
    // vertical
    // 热门
    const vertical = res2.data.res.vertical;
    verticals = [...verticals, ...vertical];
    times++;
  }
  db.collection("hots").insertMany(verticals);
}

// 首页 分类 -  分类详情
async function get2(db) {
  const res = await axios.get("http://service.picasso.adesk.com/v1/wallpaper/category");
  const category = res.data.res.category;
  db.collection("category").insertMany(category);
  let categoryDetails = [];
  for (let index = 0; index < category.length; index++) {
    const item = category[index];
    let times = 0;
    while (times < 5) {
      const skip = times * 30;
      const res2 = await axios.get(`http://service.picasso.adesk.com/v1/vertical/category/${item.id}/vertical?limit=30&skip=${skip}&adult=false&first=1&order=new`)
      const tmpCategoryDetails = res2.data.res.vertical;
      categoryDetails = [...categoryDetails, ...tmpCategoryDetails];
      times++;
    }
  }

  db.collection("categoryDetails").insertMany(categoryDetails);
}

// 首页 最新
async function get3(db) {
  let times = 0;
  let latest = [];
  while (times < 5) {
    const skip = times * 30;
    const res = await axios.get(`http://service.picasso.adesk.com/v1/vertical/vertical?limit=30&skip=${skip}&adult=false&first=1&order=new`)
    const tmpLatest = res.data.res.vertical;
    latest = [...latest, ...tmpLatest];
    times++;
  }
  db.collection("latest").insertMany(latest);
}

// 首页 专辑 专辑详情
async function get4(db) {
  let times = 0;
  let album = [];
  while (times < 3) {
    const skip = times * 30;
    const res = await axios.get(`http://service.picasso.adesk.com/v1/vertical/album?limit=30&skip=${skip}&adult=false&first=0&order=new`)
    const tmpAlbum = res.data.res.album;
    album = [...album, ...tmpAlbum];
    times++;
  }
  db.collection("album").insertMany(album);

  // 加载专辑详情
  let albumDetail = [];
  for (let index = 0; index < album.length; index++) {
    const element = album[index];
    let times_in = 0;
    while (times_in < 3) {
      const skip_in = times_in * 30;
      await sleep(100);
      const res_in = await axios.get(`http://service.picasso.adesk.com/v1/vertical/album/${element.id}/vertical?limit=30&skip=${skip_in}&adult=false&first=1&order=new`, {
        headers: {
          "User-Agent": "picasso,280,xiaomi"
        }
      })
      const tmpAlbumDetail = res_in.data.res.vertical;
      if (tmpAlbumDetail.length === 0) {
        break;
      } else {
        tmpAlbumDetail.forEach(v => {
          v.pid = element.id;
        });
        albumDetail = [...albumDetail, ...tmpAlbumDetail];
        times_in++;
      }
    }
  }
  db.collection("albumDetail").insertMany(albumDetail);
}

// 获取 视频
async function get5(db) {
  let times = 0;
  let video = [];
  while (times < 3) {
    const skip = times * 30;
    const res = await axios.get(`https://service.videowp.adesk.com/v1/videowp/featured`,
      {
        params: {
          skip,
          limit: 30,
          adult: false,
          first: 0,
          order: "hot"
        },
        headers: {
          "User-Agent": "picasso,280,xiaomi"
        }
      }
    )
    const tmpVideo = res.data.res.videowp;
    video = [...video, ...tmpVideo];
    times++;
  }
  db.collection("video").insertMany(video);

}



function sleep(num) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve();
    }, num);
  })
}