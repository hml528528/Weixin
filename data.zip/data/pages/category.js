const Router = require("@koa/router");
const router = new Router();
router.prefix("/category");

// 分类
router.get("/", async (ctx, next) => {
  const category = await ctx.db.collection('category').find({}).toArray();
  ctx.body = JSON.stringify({ data: category, code: 0, msg: "获取成功" });
  next();
});

// 分类详情
router.get("/:id", async (ctx, next) => {
  const id = ctx.params.id;
  if (!id) {
    ctx.body = JSON.stringify({ code: 1, data: null, msg: "id不能为空" })
    return;
  }
  let isOk = ["skip", "limit", "order"].every(v => Object.keys(ctx.query).includes(v));
  if (!isOk) {
    ctx.body = JSON.stringify({ code: 1, data: null, msg: "请求参数不合法" })
    return;
  }

  let { limit, skip, order } = ctx.query;

  limit = +limit;
  skip = +skip;
 
  const categoryDetail = await ctx.db.collection('categoryDetail').find({ 'cid.0': id }, { limit, skip }).sort({ _id: order === "hot" ? 1 : -1 }).toArray();
  const total = await ctx.db.collection('categoryDetail').find({ 'cid.0': id }).count();
  ctx.body = JSON.stringify({ data: { list: categoryDetail, total }, code: 0, msg: "获取成功" });
  next();
});


module.exports = router;