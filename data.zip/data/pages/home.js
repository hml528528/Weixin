
const Router = require("@koa/router");
const router = new Router();
router.prefix("/home");



// 小编推荐
router.get("/cover", async (ctx, next) => {
  const covers = await ctx.db.collection('cover').find({}).toArray();
  ctx.body = JSON.stringify({ data: covers, code: 0, msg: "获取成功" });
  next();
})

// 月份
router.get("/month", async (ctx, next) => {
  const month = await ctx.db.collection('month').find({}).toArray();
  ctx.body = JSON.stringify({ data: { list: month, date: Date.now(), title: "不食人间烟火" }, code: 0, msg: "获取成功" });
  next();
});

// 热门
router.get("/hot", async (ctx, next) => {
  let isOk = ["skip", "limit"].every(v => Object.keys(ctx.query).includes(v));
  if (!isOk) {
    ctx.body = JSON.stringify({ code: 1, data: null, msg: "请求参数不合法" })
    return;
  }
  let { limit, skip } = ctx.query;
  limit = +limit;
  skip = +skip;
  const hots = await ctx.db.collection('hot').find({}, { limit, skip }).toArray();
  const total = await ctx.db.collection('hot').find().count();
  ctx.body = JSON.stringify({ data: { list: hots, total }, code: 0, msg: "获取成功" });
  next();
});





module.exports = router;
