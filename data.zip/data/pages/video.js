const Router = require("@koa/router");
const router = new Router();
router.prefix("/video");


// 视频
router.get("/", async (ctx, next) => {
  let isOk = ["skip", "limit"].every(v => Object.keys(ctx.query).includes(v));
  if (!isOk) {
    ctx.body = JSON.stringify({ code: 1, data: null, msg: "请求参数不合法" })
    return;
  }
  let { limit, skip } = ctx.query;
  limit = +limit;
  skip = +skip;
  const video = await ctx.db.collection('video').find({ }, { limit, skip }).toArray();
  const total = await ctx.db.collection('video').count();
  ctx.body = JSON.stringify({ data: { list: video, total }, code: 0, msg: "获取成功" });
  next();
});

// 视频详情
// router.get("/:id", async (ctx, next) => {
//   const id = ctx.params.id;
//   if (!id) {
//     ctx.body = JSON.stringify({ code: 1, data: null, msg: "id不能为空" })
//     return;
//   }
//   let isOk = ["skip", "limit"].every(v => Object.keys(ctx.query).includes(v));
//   if (!isOk) {
//     ctx.body = JSON.stringify({ code: 1, data: null, msg: "请求参数不合法" })
//     return;
//   }

//   let { limit, skip } = ctx.query;

//   limit = +limit;
//   skip = +skip;
 
//   const albumDetail = await ctx.db.collection('albumDetail').find({ pid: id }, { limit, skip }).toArray();
//   const total = await ctx.db.collection('albumDetail').find({ pid: id }).count();
//   ctx.body = JSON.stringify({ data: { list: albumDetail, total }, code: 0, msg: "获取成功" });
//   next();
// });

module.exports = router;